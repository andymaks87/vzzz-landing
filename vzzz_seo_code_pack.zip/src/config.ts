// Configuration file for VZZZ Website

// Replace this URL with your deployed Google Apps Script Web App URL
// IMPORTANT: Publish > Deploy as Web App > Execute as: Me > Who has access: Anyone
export const APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbz7IyJ4coFHYH9pbyqeokarkip5xJ-NlpWvONwchEpj-ZikFjrT56d3a5Kjak4wThgk/exec';
